module com.example.javafxbadmanplayer {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media;

    requires java.desktop;
    requires javafx.graphics;
    requires java.sql;




    opens com.example.javafxbadmanplayer to javafx.fxml;
    exports com.example.javafxbadmanplayer;
}